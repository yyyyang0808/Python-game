import os
import tkinter as tk
import random

import companion

from dot import BasicDot
from game import CompanionGame
from modules.ee import EventEmitter
from util import ImageManager, load_image
from view import ObjectivesView


class InfoPanel(tk.Frame):
    """The information panel class"""
    def __init__(self, main_app):
        """Constructor

        Parameters:
            main_app: The main game application.
        """
        super().__init__(main_app._master)
        self._create_labels()

    def _create_labels(self):
        """Creates all necessary labels"""
        PADX = 50
        PADY = 20
        FONT_SIZE = 30

        self._left_frame = tk.Frame(self)
        self._center_frame = tk.Frame(self)
        self._right_frame = tk.Frame(self)
        self._bottom_frame = tk.Frame(self)

        self._left_frame.grid(row=0, column=0, padx=PADX, pady=PADY, sticky=tk.W + tk.E)
        self._center_frame.grid(row=0, column=1, padx=PADX, pady=PADY, sticky=tk.W + tk.E)
        self._right_frame.grid(row=0, column=2, padx=PADX, pady=PADY, sticky=tk.W + tk.E)
        self._bottom_frame.grid(row=1, columnspan=3, padx=PADX, pady=PADY, sticky=tk.W + tk.E)

        # make frames grow
        for x in range(3):
            tk.Grid.columnconfigure(self, x, weight=1)
        for y in range(2):
            tk.Grid.rowconfigure(self, y, weight=1)

        PHOTO_FILE_PATH = os.path.join(os.getcwd(), "images\\companions")
        photo = load_image(prefix=PHOTO_FILE_PATH, size=(180, 180),
                           image_id="eskimo", suffix=".png")

        self._lbl_remaining_moves = tk.Label(self._left_frame,
                                             font=("Helvetica", FONT_SIZE),
                                             text="remaining moves")
        self._lbl_score = tk.Label(self._center_frame,
                                   font=("Helvetica", FONT_SIZE),
                                   text="score")

        self._objectives_view = ObjectivesView(self._right_frame,
                                               image_manager=ImageManager())

        self._objectives_view.grid(column=4, row=1)

        self._lbl_companion = tk.Label(self._center_frame,
                                       image=photo)
        self._lbl_companion.photo = photo

        self._lbl_remaining_moves.grid(row=0, rowspan=2, sticky=tk.N)
        self._lbl_score.grid(column=0, row=1, sticky=tk.W + tk.E)
        self._lbl_companion.grid(column=1, row=0, sticky=tk.W + tk.E)
        self._objectives_view.grid(row=0, rowspan=3, columnspan=4)

    def set_remaining_moves(self, moves):
        self._lbl_remaining_moves.config(text=moves)

    def set_score(self, score):
        self._lbl_score.config(text=score)

    def set_objectives(self, objectives):
        self._objectives_view.draw(objectives) # not sure why this doesn't draw the dots
        # pass


class IntervalBar(tk.Canvas):
    """A bar showing intervals"""

    def __init__(self, master, steps: int):
        self._rect_height = 50
        self._interval_width = 150
        self._master = master
        self._max_moves = steps
        self._current_moves = 0

        self._rects = []
        super().__init__(master, width=self._interval_width * steps, height=self._rect_height)
        self.pack(side=tk.TOP)
        self.create_rectangle(10, 10, self._interval_width * steps, self._rect_height, dash=(2, 2))

        for i in range(steps):
            self.create_line(i * self._interval_width, 10, i * self._interval_width, 50)

    def add_one(self):
        """Add one rectangular to the progress bar"""
        print("Called me?")
        self._current_moves = self._current_moves + 1
        if (self._current_moves == 7):
            self._current_moves = 0
            for i in self._rects:
                self.delete(i)
            self._rects = []
            self._current_moves = self._current_moves + 1

        id = self.create_rectangle(10, 10,
                                   self._interval_width * self._current_moves,
                                   self._rect_height, fill="blue")
        self._rects.append(id)

    def reset(self):
        for id in self._rects:
            self.delete(id)
        self._rects = []
        self._current_moves = 0

class MenuBar(tk.Menu):
    """A menu bar"""
    def __init__(self, main_app):
        self._main_app = main_app
        self._master=main_app._master
        super().__init__(main_app._master)
        filemenu = tk.Menu(self, tearoff=0)
        filemenu.add_command(label="New Game", command=main_app.reset)
        filemenu.add_command(label="New Normal Game", command=self.normal_game)
        filemenu.add_command(label="New Companion Game", command=self.companion_game)
        # filemenu.add_command(label="Save", command=self.save_file)
        filemenu.add_command(label="Exit", command=self._confirm_exit)
        # filemenu.add_command(label="Load", command=self.load_file)
        self.add_cascade(label="File", menu=filemenu)
        self._master.config(menu=self)

    def _confirm_exit(self):
        """Confirm exit"""
        top = tk.Toplevel()
        top.title("Are you sure?")

        msg = tk.Message(text="Are you sure to quit?")
        msg.pack()
        btnSure = tk.Button(top, text="Quit", command=quit)
        btnSure.pack()
        btnCancel = tk.Button(top, text="Cancel", command=top.destroy)
        btnCancel.pack()

    def companion_game(self):
        """Activates a companion game"""
        self._main_app.new_game("Companion")
    def normal_game(self):
        """Activates a normal game"""
        self._main_app.new_game("Normal")


class CompanionDot(BasicDot):
    """The ocmpanion dot"""
    DOT_NAME = "companion"
    def __init__(self, kind):
        super().__init__(kind)
        self._ee = EventEmitter()

    def activate(self, position, game, activated, has_loop=False):
        super().activate(position,game, activated,has_loop)
        game.companion.charge()
        game.emit("charge_one")
        print("activated companion dot")

class SwirlDot(BasicDot):
    """The swirl dot"""
    DOT_NAME = "swirl"

    def activate(self, position, game, activated, has_loop=False):
        super().activate(position,game,activated,has_loop)
        row, col = position
        for i in range(-1, 2):
            for j in range(-1, 2):
                if (row+i, col+j) != position:
                    try:
                        game.grid[(row+i,col+j)].set_dot(BasicDot(self.get_kind()))
                    except:
                        print("This is a dead cell")

class EskimoCompanion(companion.AbstractCompanion):
    """The Eskimo Companion"""
    NAME = "Eskimo"

    def __init__(self, max_charge=6):
        super().__init__(max_charge)


    def activate(self, game:CompanionGame):
        """Activates the companion's ability"""
        # The following code may be useful when you are implementing task 2:
        for i in range(0, random.randint(1, 5)):
            try:
                position = random.randint(1,6), random.randint(1,6)
                game.grid[position].set_dot(SwirlDot(random.randint(1,4)))
            except:
                print("This is a dead cell.")
        self.reset()