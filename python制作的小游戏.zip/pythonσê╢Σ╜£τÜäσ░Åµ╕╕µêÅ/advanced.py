import os

import pygame

def play_music(MUSIC, volume):
    """Play background music

    Parameters:
        MUSIC (str): The music file name.
        volume (float): Music volumn. Range: 0.0 to 1.0.
    """

    # music credit: https://www.bensound.com
    pygame.init()
    pygame.mixer.init()
    f = os.path.join(os.path.dirname(__file__), "music", MUSIC)

    pygame.mixer.music.load(f)
    pygame.mixer.music.set_volume(volume)
    pygame.mixer.music.play(loops=-1)